module.exports = require("bindings")("keylogger");
